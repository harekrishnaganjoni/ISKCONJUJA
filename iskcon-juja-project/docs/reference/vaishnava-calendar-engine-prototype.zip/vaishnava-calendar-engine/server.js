const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// Import existing modules
const { getVaishnavaData } = require('./calendarEngine');
const { getDailyContent } = require('./dailyContent');

// 1. Tithi / Widget Endpoint
app.get('/widget-data', (req, res) => {
  const data = getVaishnavaData();
  res.json(data);
});

// 2. Daily Quote & Sastra Verse Endpoint
app.get('/api/daily-quote', (req, res) => {
    const today = new Date().toISOString().split('T')[0];
    const content = getDailyContent(today);
    res.json(content);
  });

// 3. Simple In-Memory Event Endpoint (Placeholder for database integration)
let events = [];
app.get('/api/events', (req, res) => res.json(events));
app.post('/api/events', (req, res) => {
  const newEvent = req.body;
  events.push(newEvent);
  res.json({ success: true, event: newEvent });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running with CORS on http://localhost:${PORT}`);
});