const db = require('./database');

/**
 * Bulk imports an array of Sastra verses into the local SQLite database for offline access.
 */
function importOfflineVerses(verseList) {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      const stmt = db.prepare(
        "INSERT OR REPLACE INTO verses (reference, sanskrit, translation) VALUES (?, ?, ?)"
      );

      db.run("BEGIN TRANSACTION");
      verseList.forEach(v => {
        stmt.run(v.reference, v.sanskrit, v.translation);
      });
      db.run("COMMIT", (err) => {
        stmt.finalize();
        if (err) reject(err);
        else {
          console.log(`Successfully loaded ${verseList.length} verses for offline use.`);
          resolve();
        }
      });
    });
  });
}

module.exports = { importOfflineVerses };