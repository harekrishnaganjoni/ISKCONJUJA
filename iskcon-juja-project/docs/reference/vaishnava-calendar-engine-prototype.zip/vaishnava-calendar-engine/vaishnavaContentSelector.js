const db = require('./databaseEngine');
const { getVaishnavaDate } = require('./calendarEngine');

/**
 * Retrieves the full verse payload and Prabhupada historical entry for today's Vaishnava date.
 */
function getDailyVaishnavaContent(dateString, latitude, longitude, timeZone) {
  return new Promise((resolve, reject) => {
    // 1. Calculate today's exact Vaishnava calendar position
    const vDate = getVaishnavaDate(dateString, latitude, longitude, timeZone);

    // 2. Fetch Prabhupada quote spoken/written on this exact Vaishnava Masa & Tithi
    const quoteQuery = `
      SELECT event_type, location, historical_year, quote, source_reference, full_context_text
      FROM prabhupada_calendar_quotes
      WHERE gaurabda_masa = ? AND gaurabda_tithi = ?
      LIMIT 1
    `;

    db.get(quoteQuery, [vDate.masa, vDate.tithi], (err, quoteRow) => {
      if (err) return reject(err);

      // Fallback query if no historical match exists on this exact Tithi
      const fallbackQuoteQuery = `SELECT event_type, location, historical_year, quote, source_reference, full_context_text FROM prabhupada_calendar_quotes LIMIT 1`;

      db.get(quoteRow ? quoteQuery : fallbackQuoteQuery, quoteRow ? [vDate.masa, vDate.tithi] : [], (err, finalQuote) => {
        if (err) return reject(err);

        // 3. Fetch Verse of the Day with full BBT fields (Sanskrit, Transliteration, Synonyms, Translation, Purport)
        const verseQuery = `
          SELECT reference, sanskrit, transliteration, synonyms, translation, purport
          FROM sastra_verses
          ORDER BY id ASC
          LIMIT 1
        `;

        db.get(verseQuery, [], (err, verseRow) => {
          if (err) return reject(err);

          resolve({
            vaishnavaDate: vDate,
            verseOfDay: verseRow || null,
            prabhupadaQuote: finalQuote || null
          });
        });
      });
    });
  });
}

module.exports = { getDailyVaishnavaContent };
