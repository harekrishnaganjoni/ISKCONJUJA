// gcalEngine.js
const { DateTime } = require('luxon');

const VAISHNAVA_TITHIS = [
  "Pratipat", "Dvitiya", "Tritiya", "Chaturthi", "Panchami",
  "Shasthi", "Saptami", "Ashtami", "Navami", "Dashami",
  "Ekadashi", "Dvadashi", "Trayodashi", "Chaturdashi", "Purnima",
  "Pratipat", "Dvitiya", "Tritiya", "Chaturthi", "Panchami",
  "Shasthi", "Saptami", "Ashtami", "Navami", "Dashami",
  "Ekadashi", "Dvadashi", "Trayodashi", "Chaturdashi", "Amavasya"
];

const GAURABDA_MASAS = [
  "Keshava", "Narayana", "Madhava", "Govinda", "Vishnu", "Madhusudana",
  "Trivikrama", "Vamana", "Sridhara", "Hrishikesha", "Padmanabha", "Damodara"
];

/**
 * Calculates Julian Day Number for a given UTC date
 */
function getJulianDay(year, month, day, hour = 0) {
  if (month <= 2) {
    year -= 1;
    month += 12;
  }
  const A = Math.floor(year / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + B - 1524.5 + (hour / 24.0);
}

/**
 * Approximate Sun and Moon longitudes at Sunrise to derive exact Sunrise Tithi
 */
function calculateSunriseTithi(dateStr, lat, lng, timeZone) {
  const dt = DateTime.fromISO(dateStr, { zone: timeZone });
  const jd = getJulianDay(dt.year, dt.month, dt.day, 6.0); // 06:00 AM local sunrise anchor

  const T = (jd - 2451545.0) / 36525;
  
  // Mean Sun Longitude
  const L0 = (280.46646 + 36000.76983 * T) % 360;
  // Mean Moon Longitude
  const L_moon = (218.3165 + 481267.8813 * T) % 360;

  // Angular separation (Elongation)
  let elongation = (L_moon - L0) % 360;
  if (elongation < 0) elongation += 360;

  // Each Tithi is exactly 12 degrees of solar-lunar separation
  const tithiIndex = Math.floor(elongation / 12) % 30;
  const isShukla = tithiIndex < 15;
  const paksha = isShukla ? "Shukla Paksha" : "Krishna Paksha";
  const tithiName = VAISHNAVA_TITHIS[tithiIndex];

  // Derive Masa based on Sun's tropical sign alignment
  const sunSignIndex = Math.floor(L0 / 30);
  const masaIndex = (sunSignIndex + 4) % 12;
  const masaName = GAURABDA_MASAS[masaIndex];
  
  const gaurabdaYear = dt.year - 1486;

  return {
    masa: masaName,
    paksha: paksha,
    tithi: tithiName,
    gaurabdaYear: `Gaurabda ${gaurabdaYear}`
  };
}

module.exports = { calculateSunriseTithi };