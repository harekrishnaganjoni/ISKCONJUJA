const { getDailyVaishnavaContent } = require('./vaishnavaContentSelector');
const { generateNotificationQueue } = require('./notificationRouter');
const { createShareableEvent } = require('./eventSharing');

const lat = -1.286389;
const lng = 36.817223;
const tz = "Africa/Nairobi";

const userPreferences = {
  notify_tithis: true,
  tithi_time: 'BRAHMA_MUHURTA',
  notify_festivals: true,
  festival_time: 'BRAHMA_MUHURTA',
  notify_verses: true,
  verse_time: '07:00',
  notify_quotes: true,
  quote_time: '18:00'
};

/**
 * Calculates Vaishnava content for any target date string (YYYY-MM-DD)
 */
async function getEngineDataForDate(targetDate) {
  const dailyContent = await getDailyVaishnavaContent(targetDate, lat, lng, tz);
  const queue = generateNotificationQueue(
    targetDate, 
    lat, 
    lng, 
    tz, 
    userPreferences, 
    dailyContent.verseOfDay, 
    dailyContent.prabhupadaQuote
  );

  return {
    targetDate,
    dailyContent,
    notificationQueue: queue
  };
}

/**
 * Main execution function using system's current live date
 */
async function runEngine() {
  const today = new Date().toISOString().split('T')[0];
  console.log(`=== VAISHNAVA CALENDAR ENGINE ===\nDate: ${today} | Location: ${tz}\n`);

  const { dailyContent, notificationQueue } = await getEngineDataForDate(today);

  console.log("--- Today's Vaishnava Date ---");
  console.log(`Masa   : ${dailyContent.vaishnavaDate.masa} Masa`);
  console.log(`Paksha: ${dailyContent.vaishnavaDate.paksha}`);
  console.log(`Tithi : ${dailyContent.vaishnavaDate.tithi}\n`);

  console.log("--- Verse of the Day (Full BBT Structure) ---");
  if (dailyContent.verseOfDay) {
    console.log(`Reference      : ${dailyContent.verseOfDay.reference}`);
    console.log(`Sanskrit       : ${dailyContent.verseOfDay.sanskrit.split('\n')[0]}...`);
    console.log(`Transliteration: ${dailyContent.verseOfDay.transliteration.split('\n')[0]}...`);
    console.log(`Synonyms       : ${dailyContent.verseOfDay.synonyms.substring(0, 60)}...`);
    console.log(`Translation    : ${dailyContent.verseOfDay.translation}`);
    console.log(`Purport        : ${dailyContent.verseOfDay.purport.substring(0, 100)}...\n`);
  }

  console.log("--- Prabhupada Historical Calendar Entry ---");
  if (dailyContent.prabhupadaQuote) {
    console.log(`Quote: "${dailyContent.prabhupadaQuote.quote}"`);
    console.log(`Source: ${dailyContent.prabhupadaQuote.source_reference}\n`);
  }

  console.log("--- Scheduled Push Notification Queue ---");
  console.log(JSON.stringify(notificationQueue, null, 2));

  console.log("\n--- Personal Shared Event Card ---");
  const inviteCard = createShareableEvent("Janmashtami House Kirtan", "2026-09-04", lat, lng, tz, "Duncan");
  console.log(JSON.stringify(inviteCard, null, 2));
}

// Execute standalone CLI run only if called directly
if (require.main === module) {
  runEngine().catch(console.error);
}

module.exports = {
  getEngineDataForDate,
  runEngine
};