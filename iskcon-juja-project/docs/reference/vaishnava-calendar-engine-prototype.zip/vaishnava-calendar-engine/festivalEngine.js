// Mapping Ekadashis by Masa (Lunar Month) and Paksha
const EKADASHI_NAMES = {
  "Vishnu": { "Shukla Paksha": "Kamada Ekadashi", "Krishna Paksha": "Varuthini Ekadashi" },
  "Madhusudana": { "Shukla Paksha": "Mohini Ekadashi", "Krishna Paksha": "Apara Ekadashi" },
  "Trivikrama": { "Shukla Paksha": "Nirjala Ekadashi", "Krishna Paksha": "Yogini Ekadashi" },
  "Vamana": { "Shukla Paksha": "Devashayani Ekadashi", "Krishna Paksha": "Kamika Ekadashi" },
  "Sridhara": { "Shukla Paksha": "Pavitropana Ekadashi", "Krishna Paksha": "Annada Ekadashi" },
  "Hrishikesha": { "Shukla Paksha": "Parsva Ekadashi", "Krishna Paksha": "Indira Ekadashi" },
  "Padmanabha": { "Shukla Paksha": "Pasankusa Ekadashi", "Krishna Paksha": "Rama Ekadashi" },
  "Damodara": { "Shukla Paksha": "Utthana Ekadashi", "Krishna Paksha": "Utpanna Ekadashi" },
  "Keshava": { "Shukla Paksha": "Moksada Ekadashi", "Krishna Paksha": "Saphala Ekadashi" },
  "Narayana": { "Shukla Paksha": "Putrada Ekadashi", "Krishna Paksha": "Sattila Ekadashi" },
  "Madhava": { "Shukla Paksha": "Jaya Ekadashi", "Krishna Paksha": "Vijaya Ekadashi" },
  "Govinda": { "Shukla Paksha": "Amalaki Ekadashi", "Krishna Paksha": "Papamocani Ekadashi" }
};

// Major Fixed Festivals
const VAISHNAVA_FESTIVALS = {
  "Sridhara_Krishna Paksha_Ashtami": "Sri Krishna Janmashtami",
  "Sridhara_Shukla Paksha_Navami": "Sri Radhashtami",
  "Govinda_Shukla Paksha_Chaturdashi": "Gaura Purnima",
  "Vishnu_Shukla Paksha_Navami": "Rama Navami",
  "Madhusudana_Shukla Paksha_Tritiya": "Akshaya Tritiya",
  "Trivikrama_Shukla Paksha_Narasimha Caturdasi": "Nrsimha Caturdasi"
};

function getFestivalDetails(masa, paksha, tithi) {
  let festival = null;
  let ekadashiName = null;

  if (tithi === "Ekadashi") {
    ekadashiName = EKADASHI_NAMES[masa]?.[paksha] || "Ekadashi Fast";
  }

  const festivalKey = `${masa}_${paksha}_${tithi}`;
  if (VAISHNAVA_FESTIVALS[festivalKey]) {
    festival = VAISHNAVA_FESTIVALS[festivalKey];
  }

  return { ekadashiName, festival };
}

module.exports = { getFestivalDetails };