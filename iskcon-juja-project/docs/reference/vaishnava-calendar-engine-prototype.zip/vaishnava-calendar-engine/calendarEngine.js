const { calculateSunriseTithi } = require('./gcalEngine');

/**
 * Calculates local Vaishnava calendar parameters using Gcal sunrise tithi math.
 */
function getVaishnavaDate(dateString, latitude, longitude, timeZone) {
  const gcalData = calculateSunriseTithi(dateString, latitude, longitude, timeZone);

  return {
    gregorianDate: dateString,
    location: { latitude, longitude, timeZone },
    gaurabdaYear: gcalData.gaurabdaYear,
    masa: gcalData.masa,
    paksha: gcalData.paksha,
    tithi: gcalData.tithi,
    isEkadashi: gcalData.tithi === "Ekadashi"
  };
}

module.exports = { getVaishnavaDate };