const db = require('./databaseEngine');

const PROD_SASTRA_VERSES = [
  {
    canto_or_chapter: "Bhagavad-gita Chapter 2",
    verse_number: "2.13",
    reference: "Bhagavad-gita 2.13",
    sanskrit: "देहिनोऽस्मिन यथा देहे कौमारं यौवनं जरा ।\nतथा देहान्तरप्राप्तिर्धीरस्तत्र न मुह्यति ॥",
    transliteration: "dehino 'smin yathā dehe kaumāraṁ yauvanaṁ jarā\ntathā dehāntara-prāptir dhīras tatra na muhyati",
    synonyms: "dehinaḥ — of the embodied; asmin — in this; yathā — as; dehe — in the body; kaumāram — boyhood; yauvanam — youth; jarā — old age; tathā — similarly; dehāntara — of transfer of the body; prāptiḥ — achievement; dhīraḥ — the sober person; tatra — thereupon; na muhyati — is not deluded.",
    translation: "As the embodied soul continuously passes, in this body, from boyhood to youth to old age, the soul similarly passes into another body at death. A sober person is not bewildered by such a change.",
    purport: "Since every living entity is an individual soul, each is changing his body at every moment, manifesting sometimes as a child, sometimes as a youth, and sometimes as an old man. Yet the same spirit soul is there and does not undergo any change. This individual soul finally changes the body itself, transmigrating from one body to another, and since it is sure to have another body in the next birth—either material or spiritual—there was no cause for lamentation by Arjuna..."
  },
  {
    canto_or_chapter: "Srimad-Bhagavatam Canto 1 Chapter 2",
    verse_number: "1.2.6",
    reference: "Srimad-Bhagavatam 1.2.6",
    sanskrit: "स वै पुंसां परो धर्मो यतो भक्तिरधोक्षजे ।\nअहैतुकी अप्रतिहता ययात्मा सम्प्रसीदति ॥",
    transliteration: "sa vai puṁsāṁ paro dharmo yato bhaktir adhokṣaje\nahaituky apratihatā yayātmā suprasīdati",
    synonyms: "saḥ — that; vai — certainly; puṁsām — for mankind; paraḥ — sublime; dharmaḥ — occupation; yataḥ — by which; bhaktiḥ — devotional service; adhokṣaje — unto the Transcendent; ahaitukī — unmotivated; apratihatā — uninterrupted; yayā — by which; ātmā — the self; suprasīdati — completely satisfied.",
    translation: "The supreme occupation for all humanity is that by which men can attain to loving devotional service unto the transcendent Lord. Such devotional service must be unmotivated and uninterrupted to completely satisfy the self.",
    purport: "In this statement of Sūta Gosvāmī, the answer that the supreme religion or occupation of man is devotional service to Adhokṣaja (Lord Kṛṣṇa) is given. Material duties are categorized into three divisions—dharma, artha, and kāma. But devotional service to Kṛṣṇa is transcendental and brings total peace to the soul..."
  },
  {
    canto_or_chapter: "Sri Caitanya-caritamrta Madhya-lila Chapter 20",
    verse_number: "20.108",
    reference: "Caitanya-caritamrta Madhya 20.108",
    sanskrit: "जीवेर 'स्वरूप' हय — कृष्णेर 'नित्य-दास' ।\nकृष्णेर 'तटस्था-शक्ति' 'भेदाभेद-प्रकाश' ॥",
    transliteration: "jīvera 'svarūpa' haya — kṛṣṇera 'nitya-dāsa'\nkṛṣṇera 'taṭasthā-śakti' 'bhedābheda-prakāśa'",
    synonyms: "jīvera — of the living entity; svarūpa — the constitutional position; haya — is; kṛṣṇera — of Lord Kṛṣṇa; nitya-dāsa — eternal servant; kṛṣṇera — of Lord Kṛṣṇa; taṭasthā — marginal; śakti — potency; bhedābheda — simultaneously one and different; prakāśa — manifestation.",
    translation: "It is the living entity's constitutional position to be an eternal servant of Kṛṣṇa because he is the marginal energy of Kṛṣṇa and a manifestation simultaneously one with and different from the Lord.",
    purport: "This is a basic principle of Vaisṇava philosophy. Lord Caitanya Mahāprabhu directly explains here that living entities are marginal potencies (taṭasthā-śakti) of the Supreme Personality of Godhead, meant eternally to serve Him..."
  }
];

const PROD_PRABHUPADA_CALENDAR = [
  {
    gaurabda_masa: "Padmanabha",
    gaurabda_tithi: "Ekadashi",
    historical_year: 1966,
    event_type: "Lecture",
    location: "New York",
    quote: "On this Ekadashi day, practice chanting Hare Krishna continuously. The spirit soul is beyond birth and death.",
    source_reference: "Bhagavad-gita 2.13 Lecture, New York, July 1966",
    full_context_text: "Ekadashi fasting is meant for spiritual advancement. When you minimize the demands of the body, the mind becomes clear to absorb the transcendental sound vibration..."
  },
  {
    gaurabda_masa: "Damodara",
    gaurabda_tithi: "Ashtami",
    historical_year: 1972,
    event_type: "Nectar of Devotion Lecture",
    location: "Vrindavan",
    quote: "Vrindavan is not a material place; it is the personal abode of Radha and Krishna manifested on Earth.",
    source_reference: "Lecture on Radhashtami, Vrindavan, September 1972",
    full_context_text: "Radharani is the pleasure potency of Krishna. By seeking Her mercy, devotional service becomes instantly accessible and joyful..."
  }
];

db.serialize(() => {
  // Insert Verses
  const stmtVerse = db.prepare(`
    INSERT OR REPLACE INTO sastra_verses 
    (canto_or_chapter, verse_number, reference, sanskrit, transliteration, synonyms, translation, purport) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  PROD_SASTRA_VERSES.forEach(v => {
    stmtVerse.run(v.canto_or_chapter, v.verse_number, v.reference, v.sanskrit, v.transliteration, v.synonyms, v.translation, v.purport);
  });
  stmtVerse.finalize();

  // Insert Calendar-Mapped Prabhupada Entries
  const stmtQuote = db.prepare(`
    INSERT OR REPLACE INTO prabhupada_calendar_quotes 
    (gaurabda_masa, gaurabda_tithi, historical_year, event_type, location, quote, source_reference, full_context_text) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  PROD_PRABHUPADA_CALENDAR.forEach(q => {
    stmtQuote.run(q.gaurabda_masa, q.gaurabda_tithi, q.historical_year, q.event_type, q.location, q.quote, q.source_reference, q.full_context_text);
  });
  stmtQuote.finalize();

  console.log("Database successfully seeded with production ISKCON Sastra and calendar-mapped Prabhupada entries.");
});