const { Solar, Lunar } = require('lunar-javascript');
const { getVaishnavaDate } = require('./calendarEngine');

/**
 * Converts a Gregorian milestone date (e.g. Birthday) to its corresponding Vaishnava date profile.
 */
function registerMilestone(name, originalDate, latitude, longitude, timeZone) {
  const originalProfile = getVaishnavaDate(originalDate, latitude, longitude, timeZone);
  
  return {
    name,
    originalGregorianDate: originalDate,
    vaishnavaTarget: {
      masa: originalProfile.masa,
      paksha: originalProfile.paksha,
      tithi: originalProfile.tithi
    }
  };
}

/**
 * Finds the Gregorian date for a registered Vaishnava milestone in a given target year.
 */
function findMilestoneInYear(milestone, targetYear, latitude, longitude, timeZone) {
  // Scans days in the target year to match the milestone's Masa, Paksha, and Tithi
  let startSolar = Solar.fromYmd(targetYear, 1, 1);
  let endSolar = Solar.fromYmd(targetYear, 12, 31);
  
  for (let d = startSolar; d.isBefore(endSolar); d = d.next(1)) {
    const checkDate = `${d.getYear()}-${String(d.getMonth()).padStart(2, '0')}-${String(d.getDay()).padStart(2, '0')}`;
    const profile = getVaishnavaDate(checkDate, latitude, longitude, timeZone);
    
    if (
      profile.masa === milestone.vaishnavaTarget.masa &&
      profile.paksha === milestone.vaishnavaTarget.paksha &&
      profile.tithi === milestone.vaishnavaTarget.tithi
    ) {
      return {
        milestoneName: milestone.name,
        targetYear: targetYear,
        occurrenceDate: checkDate,
        vaishnavaDetails: profile
      };
    }
  }
  return null;
}

module.exports = { registerMilestone, findMilestoneInYear };