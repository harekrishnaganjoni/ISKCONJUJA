// Predetermined sequence of daily verses from Sastra
const SASTRA_VERSES = [
  {
    reference: "Bhagavad-gita 2.13",
    text: "dehino 'smin yatha dehe kaumaram yauvanam jara, tatha dehantara-praptir dhiras tatra na muhyati.",
    translation: "As the embodied soul continuously passes, in this body, from boyhood to youth to old age, the soul similarly passes into another body at death. A sober person is not bewildered by such a change."
  },
  {
    reference: "Bhagavad-gita 9.26",
    text: "patram puspam phalam toyam yo me bhaktya prayacchati, tad aham bhakty-upahrtam asnami prayatatmanah.",
    translation: "If one offers Me with love and devotion a leaf, a flower, fruit or water, I will accept it."
  },
  {
    reference: "Srimad-Bhagavatam 1.2.6",
    text: "sa vai pumsam paro dharmo yato bhaktir adhoksaje, ahaituky apratihata yayatma suprasidati.",
    translation: "The supreme occupation for all humanity is that by which men can attain to loving devotional service unto the transcendent Lord. Such devotional service must be unmotivated and uninterrupted to completely satisfy the self."
  }
];

// Historical Prabhupada quotes mapped by day of the year (1-365)
const PRABHUPADA_QUOTES = [
  {
    dayOfYear: 1,
    quote: "Chant Hare Krishna and your life will be sublime.",
    source: "Lecture, New York, 1966"
  },
  {
    dayOfYear: 2,
    quote: "Krsna consciousness is not an artificial imposition on the mind; this consciousness is the original natural energy of the living entity.",
    source: "The Nectar of Devotion"
  }
];

/**
 * Retrieves daily content using a deterministic index based on the day of the year.
 */
function getDailyContent(dateString) {
  const date = new Date(dateString);
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date - start;
  const oneDay = 1000 * 60 * 60 * 24;
  const dayOfYear = Math.floor(diff / oneDay);

  // Use modulo division to cycle sequentially without random loops
  const verseIndex = (dayOfYear - 1) % SASTRA_VERSES.length;
  const quoteIndex = (dayOfYear - 1) % PRABHUPADA_QUOTES.length;

  return {
    verseOfDay: SASTRA_VERSES[verseIndex],
    prabhupadaQuote: PRABHUPADA_QUOTES[quoteIndex]
  };
}

module.exports = { getDailyContent };