const { DateTime } = require('luxon');
const { getVaishnavaDate } = require('./calendarEngine');
const { getFestivalDetails } = require('./festivalEngine');

/**
 * Calculates local Brahma Muhurta time (~96 mins before sunrise)
 */
function getBrahmaMuhurtaTime(dateString, timeZone) {
  const baseSunrise = DateTime.fromISO(`${dateString}T06:00:00`, { zone: timeZone });
  return baseSunrise.minus({ minutes: 96 }).toFormat('HH:mm');
}

/**
 * Helper to resolve whether to use Brahma Muhurta or a custom HH:MM time
 */
function resolveTime(settingTime, dateString, timeZone) {
  return settingTime === 'BRAHMA_MUHURTA' 
    ? getBrahmaMuhurtaTime(dateString, timeZone) 
    : settingTime;
}

/**
 * Generates modular notification alerts scheduled at individual category times
 */
function generateNotificationQueue(dateString, latitude, longitude, timeZone, userSettings, verseData, quoteData) {
  const vDate = getVaishnavaDate(dateString, latitude, longitude, timeZone);
  const { ekadashiName, festival } = getFestivalDetails(vDate.masa, vDate.paksha, vDate.tithi);
  
  const notificationQueue = [];

  // Channel 1: Tithi / Ekadashi Alerts
  if (userSettings.notify_tithis && vDate.isEkadashi) {
    notificationQueue.push({
      channel: "TITHI_ALERTS",
      scheduledTime: resolveTime(userSettings.tithi_time, dateString, timeZone),
      payload: {
        title: `🔔 ${ekadashiName}`,
        body: `Today is ${ekadashiName} (${vDate.masa} Masa). Fasting from grains & beans.`
      }
    });
  }

  // Channel 2: Vaishnava Festivals
  if (userSettings.notify_festivals && festival) {
    notificationQueue.push({
      channel: "FESTIVAL_ALERTS",
      scheduledTime: resolveTime(userSettings.festival_time, dateString, timeZone),
      payload: {
        title: `🛕 ${festival}`,
        body: `Today is the auspicious observance of ${festival}.`
      }
    });
  }

  // Channel 3: Daily Verse
  if (userSettings.notify_verses && verseData) {
    notificationQueue.push({
      channel: "DAILY_VERSE",
      scheduledTime: resolveTime(userSettings.verse_time, dateString, timeZone),
      payload: {
        title: `📖 Verse of the Day: ${verseData.reference}`,
        body: `"${verseData.translation}"`
      }
    });
  }

  // Channel 4: Prabhupada Quote
  if (userSettings.notify_quotes && quoteData) {
    const quoteSource = quoteData.source_reference || quoteData.source || "";
    notificationQueue.push({
      channel: "PRABHUPADA_QUOTE",
      scheduledTime: resolveTime(userSettings.quote_time, dateString, timeZone),
      payload: {
        title: `💬 Srila Prabhupada Today`,
        body: `"${quoteData.quote}"${quoteSource ? ` — ${quoteSource}` : ""}`
      }
    });
  }

  return notificationQueue;
}

module.exports = { generateNotificationQueue };