const { getDailyVaishnavaContent } = require('./vaishnavaContentSelector');
const { generateNotificationQueue } = require('./notificationRouter');
const { createShareableEvent } = require('./eventSharing');

async function runProductionTestSuite() {
  console.log("==================================================");
  console.log("   VAISHNAVA CALENDAR ENGINE - TEST SUITE VERIFICATION");
  console.log("==================================================\n");

  const testCases = [
    { label: "Nairobi, Kenya (EAT)", date: "2026-08-23", lat: -1.286389, lng: 36.817223, tz: "Africa/Nairobi" },
    { label: "Mayapur, India (IST)", date: "2026-08-23", lat: 23.4241, lng: 88.3892, tz: "Asia/Kolkata" },
    { label: "Vrindavan, India (IST)", date: "2026-08-23", lat: 27.5818, lng: 77.7006, tz: "Asia/Kolkata" }
  ];

  const userSettings = {
    notify_tithis: true,
    tithi_time: 'BRAHMA_MUHURTA',
    notify_festivals: true,
    festival_time: 'BRAHMA_MUHURTA',
    notify_verses: true,
    verse_time: '07:00',
    notify_quotes: true,
    quote_time: '18:00'
  };

  for (const tc of testCases) {
    console.log(`--- [TEST LOCATION]: ${tc.label} ---`);
    const content = await getDailyVaishnavaContent(tc.date, tc.lat, tc.lng, tc.tz);

    console.log(`  Masa         : ${content.vaishnavaDate.masa}`);
    console.log(`  Paksha       : ${content.vaishnavaDate.paksha}`);
    console.log(`  Tithi        : ${content.vaishnavaDate.tithi}`);
    console.log(`  Is Ekadashi  : ${content.vaishnavaDate.isEkadashi}`);
    
    if (content.verseOfDay) {
      console.log(`  Verse Loaded : ${content.verseOfDay.reference}`);
    }
    
    if (content.prabhupadaQuote) {
      console.log(`  Quote Loaded : "${content.prabhupadaQuote.quote.substring(0, 40)}..."`);
    }

    const queue = generateNotificationQueue(tc.date, tc.lat, tc.lng, tc.tz, userSettings, content.verseOfDay, content.prabhupadaQuote);
    console.log(`  Scheduled Alerts (${queue.length}):`);
    queue.forEach(item => {
      console.log(`    - [${item.channel}] @ ${item.scheduledTime}: ${item.payload.title}`);
    });

    console.log("");
  }

  console.log("--- [TEST EVENT CARD DEEP-LINK GENERATION] ---");
  const eventPayload = createShareableEvent("Gaura Purnima Kirtan", "2026-03-03", -1.286389, 36.817223, "Africa/Nairobi", "Duncan");
  console.log(`  Event Title : ${eventPayload.title}`);
  console.log(`  Target Masa : ${eventPayload.vaishnavaTarget.masa}`);
  console.log(`  Deep Link   : ${eventPayload.deepLink.substring(0, 50)}...`);
  console.log("\n==================================================");
  console.log("   ALL CORE ENGINE MODULES FUNCTIONING OK.");
  console.log("==================================================");
}

runProductionTestSuite().catch(console.error);