const fs = require('fs');
const path = require('path');

const filesToRemove = [
  'database.js',
  'seedDatabase.js',
  'completeDataset.js'
];

filesToRemove.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
    console.log(`Removed obsolete file: ${file}`);
  } else {
    console.log(`File already clean or missing: ${file}`);
  }
});