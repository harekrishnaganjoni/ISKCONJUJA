const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./vaishnava_app.db');

db.serialize(() => {
  // 1. ISKCON Sastra Database (Full BBT standard structure)
  db.run(`CREATE TABLE IF NOT EXISTS sastra_verses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    canto_or_chapter TEXT,
    verse_number TEXT,
    reference TEXT UNIQUE,
    sanskrit TEXT,
    transliteration TEXT,
    synonyms TEXT,
    translation TEXT,
    purport TEXT
  )`);

  // 2. Historical Prabhupada Calendar Database (Mapped by Gaurabda Masa & Tithi)
  db.run(`CREATE TABLE IF NOT EXISTS prabhupada_calendar_quotes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gaurabda_masa TEXT,
    gaurabda_tithi TEXT,
    historical_year INTEGER,
    event_type TEXT, -- e.g., 'Room Conversation', 'Lecture', 'Letter', 'Arrival'
    location TEXT,
    quote TEXT,
    source_reference TEXT,
    full_context_text TEXT
  )`);
});

console.log("Full ISKCON-standard database schema initialized.");
module.exports = db;