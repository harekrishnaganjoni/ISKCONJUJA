const { getVaishnavaDate } = require('./calendarEngine');

/**
 * Creates an event and generates a shareable invitation payload/link.
 */
function createShareableEvent(title, gregorianDate, latitude, longitude, timeZone, createdBy) {
  const profile = getVaishnavaDate(gregorianDate, latitude, longitude, timeZone);
  
  const eventId = `vcal_evt_${Date.now()}`;
  const sharePayload = {
    version: "1.0",
    type: "VAISHNAVA_EVENT_INVITE",
    eventId: eventId,
    title: title,
    createdBy: createdBy,
    vaishnavaTarget: {
      masa: profile.masa,
      paksha: profile.paksha,
      tithi: profile.tithi
    },
    originalDate: gregorianDate,
    deepLink: `vcal://import-event?data=${Buffer.from(JSON.stringify({
      title,
      masa: profile.masa,
      paksha: profile.paksha,
      tithi: profile.tithi
    })).toString('base64')}`
  };

  return sharePayload;
}

module.exports = { createShareableEvent };